<?php 


$host = "localhost";
$user = "root";
$pass = "";
$database = "watchmi";

$connection = mysqli_connect($host,$user,$pass,$database);
